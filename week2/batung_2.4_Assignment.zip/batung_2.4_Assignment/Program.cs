﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace batung_2._4_Assignment
{
    public class Program
    {
        static void Main(string[] args)
        {

        }
    }
}