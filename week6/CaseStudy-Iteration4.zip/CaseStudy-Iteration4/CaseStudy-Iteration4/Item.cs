﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseStudy_Iteration4
{
    public class Item:GameObject
    {
        public Item(string[]idens,string name, string desc):base(idens,name,desc)
        {

        }
       
    }
}
