﻿using SplashKitSDK;
using Color = SplashKitSDK.Color;

namespace DrawingProgram
{
    public class MyCircle : Shape
    {
        private int oradius;
        public int Radius
        {
            get
            {
                return oradius;
            }
            set
            {
                oradius = value;
            }
        }
        public MyCircle()
        {
            X = 0;
            Y = 0;
            oradius = 50;
            Color = SplashKit.ColorBlue();
        }
        public MyCircle (Color color, int x , int y, int radius)
        {
            Color = color;
            X = x;
            Y = y;
            oradius = radius;
        }
        public override void Draw()
        {
            if (Selected) DrawOutline();
            SplashKit.FillCircle(Color, X, Y, _radius);
        }
        public override void DrawOutline() //overidde
        {
            SplashKit.FillCircle(SplashKit.ColorBlack(), X , Y, oradius + 2); //draw shape
        }
        public override bool IsAt(Point2D pt)
        {
             //check if the mouse point in the circle or not /  return the centered point of circle
            /*if (SplashKit.PointInCircle(pt, SplashKit.CircleAt(X + Radius, Y + Radius, Radius)))
            {
                return true;
            }
            else
            {
                return false;
            } */
            
            //Pythagorean theorem
            double distancex = pt.X - X; // x-coor and cirlce center
            double distancey = pt.Y - Y; // y-coor and circle center
            double distance = (distancex * distancex) + (distancey * distancey);
            double radius2 = (Radius * Radius);

            if (distance <= radius2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}

