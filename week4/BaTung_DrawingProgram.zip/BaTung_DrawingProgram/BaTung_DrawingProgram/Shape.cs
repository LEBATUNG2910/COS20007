﻿using SplashKitSDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrawingProgram
{
    public abstract class Shape
    {
        private bool _selected;
        private float ox, oy;
        private Color ocolor;
        public float X
        {
            get
            {
                return ox;
            }
            set
            {
                ox = value;
            }
        }
        public float Y
        {
            get
            {
                return oy;
            }
            set
            {
                oy = value;
            }
        }
        public bool Selected
        {
            get
            {
                return oselected;
            }
            set
            {
                oselected = value;
            }
        }
        public Color Color
        {
            get
            {
                return ocolor;
            }
            set
            {
                ocolor = value;
            }
        }
        public Shape()
        {
            ocolor = SplashKit.ColorYellow();
        }
        public Shape(Color color)
        {
            ocolor = color;
        }
        public abstract bool IsAt(Point2D pt);

        public abstract void DrawOutline();
        public abstract void Draw();

    }
}
