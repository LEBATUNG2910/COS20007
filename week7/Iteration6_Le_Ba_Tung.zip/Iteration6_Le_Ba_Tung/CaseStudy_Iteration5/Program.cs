﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CaseStudy_Iteration5
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Zombie war III");
            Console.WriteLine("Enter your name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Hello " + name + "." + " Welcome to our game");
            Console.WriteLine("Let's me take some description about your:");
            string description = Console.ReadLine();
            Player player = new Player(name, description);

            Location location = new Location(new string[] { "F22" }, "tunnel", "US army");
            player.Location = location;

            Item item1 = new Item(new string[] { "b52" }, "jet fighter", "this is the strongest plane");
            player.Inventory.Put(item1);
            Item item2 = new Item(new string[] { "m4a1" }, "auto", "this is a powerful gun");
            player.Inventory.Put(item2);
            Item item3 = new Item(new string[] { "gold" }, "knife", "this is a sharp knife");
            player.Inventory.Put(item3);
            Bag bag = new Bag(new string[] { "helicopter" }, "US army", "this is the biggest plane");
            player.Inventory.Put(bag);
            bag.Inventory.Put(item1);
            location.Inventory.Put(item1);
            location.Inventory.Put(item2);
            location.Inventory.Put(item3);
            LookCommand lk = new LookCommand();
            string text = "";
            do
            {
                Console.WriteLine("Put your command here:  ");
                text = Console.ReadLine();
                string[] array = Regex.Split(text, @"\s+");
                Console.WriteLine(lk.Execute(player, array));
            } while (text != "out");
        }
    }
}
